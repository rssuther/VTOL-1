from cv_img_stitching import img_stitching_demo
from cv_img_read import img_poi_detection_demo
from time import sleep


def main():

	while True:
		img_stitching_demo()
		sleep(2)
		img_poi_detection_demo()
		sleep(2)



if __name__ == '__main__':
	main()